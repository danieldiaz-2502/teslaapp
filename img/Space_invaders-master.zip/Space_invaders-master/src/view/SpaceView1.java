package view;

import processing.core.PApplet;

public class SpaceView1 {
	PApplet app;
	
	public SpaceView1(PApplet app) {
		this.app = app;
	}
	
	public void dibujarFondo(){
		app.background(0);
	}

}